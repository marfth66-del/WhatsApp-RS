import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // First run: configure Firebase with `flutterfire configure`.
  await Firebase.initializeApp();
  runApp(const WhatsAppRsApp());
}

class WhatsAppRsApp extends StatelessWidget {
  const WhatsAppRsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'واتساب RSッ',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101512),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF20C875),
          brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF101512),
          foregroundColor: Color(0xFF20C875),
        ),
        useMaterial3: true,
      ),
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: const AuthGate(),
    );
  }
}

class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.data == null) return const PhoneLoginPage();
        return const HomePage();
      },
    );
  }
}

class PhoneLoginPage extends StatefulWidget {
  const PhoneLoginPage({super.key});

  @override
  State<PhoneLoginPage> createState() => _PhoneLoginPageState();
}

class _PhoneLoginPageState extends State<PhoneLoginPage> {
  final phone = TextEditingController();
  final code = TextEditingController();
  String? verificationId;
  bool sending = false;
  String message = '';

  Future<void> sendCode() async {
    final number = phone.text.trim();
    if (!number.startsWith('+') || number.length < 8) {
      setState(() => message = 'اكتب الرقم مع مفتاح الدولة، مثال: +9677XXXXXXXX');
      return;
    }
    setState(() { sending = true; message = ''; });
    await FirebaseAuth.instance.verifyPhoneNumber(
      phoneNumber: number,
      timeout: const Duration(seconds: 60),
      verificationCompleted: (credential) async {
        await FirebaseAuth.instance.signInWithCredential(credential);
      },
      verificationFailed: (e) {
        if (mounted) setState(() { message = e.message ?? 'تعذر إرسال الرمز'; sending = false; });
      },
      codeSent: (id, token) {
        if (mounted) setState(() { verificationId = id; message = 'تم إرسال الرمز إذا كانت الخدمة متاحة لرقمك.'; sending = false; });
      },
      codeAutoRetrievalTimeout: (id) => verificationId = id,
    );
  }

  Future<void> verifyCode() async {
    if (verificationId == null) return;
    try {
      final credential = PhoneAuthProvider.credential(
        verificationId: verificationId!,
        smsCode: code.text.trim(),
      );
      await FirebaseAuth.instance.signInWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      setState(() => message = e.message ?? 'رمز التحقق غير صحيح');
    }
  }

  @override
  void dispose() { phone.dispose(); code.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('واتساب RSッ')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 420),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.forum_rounded, size: 76, color: Color(0xFF20C875)),
              const SizedBox(height: 12),
              const Text('تواصل بلا حدود', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              const SizedBox(height: 24),
              TextField(controller: phone, keyboardType: TextInputType.phone,
                decoration: const InputDecoration(labelText: 'رقم الهاتف مع مفتاح الدولة', hintText: '+9677XXXXXXXX', border: OutlineInputBorder())),
              const SizedBox(height: 12),
              if (verificationId != null)
                TextField(controller: code, keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'رمز SMS', border: OutlineInputBorder())),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, child: FilledButton(
                onPressed: sending ? null : (verificationId == null ? sendCode : verifyCode),
                child: Text(sending ? 'جارٍ الإرسال...' : (verificationId == null ? 'إرسال رمز التحقق' : 'تأكيد الرمز')),
              )),
              if (message.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(message, textAlign: TextAlign.center)),
              const SizedBox(height: 12),
              const Text('يلزم إعداد Firebase وتفعيل Phone Authentication قبل الاستخدام.',
                textAlign: TextAlign.center, style: TextStyle(color: Colors.white60, fontSize: 12)),
            ]),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser!;
    return Scaffold(
      appBar: AppBar(
        title: const Text('واتساب RSッ'),
        actions: [
          IconButton(tooltip: 'تسجيل الخروج', onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout)),
        ],
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            const CircleAvatar(backgroundColor: Color(0xFF20C875), child: Icon(Icons.person, color: Colors.black)),
            const SizedBox(width: 12),
            Expanded(child: Text(user.phoneNumber ?? user.uid, maxLines: 1, overflow: TextOverflow.ellipsis)),
          ]),
        ),
        const Divider(),
        const Expanded(child: UsersList()),
      ]),
    );
  }
}

class UsersList extends StatelessWidget {
  const UsersList({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: FirebaseFirestore.instance.collection('users').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) return const Center(child: Text('تعذر تحميل المستخدمين'));
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final me = FirebaseAuth.instance.currentUser!.uid;
        final docs = snapshot.data!.docs.where((d) => d.id != me).toList();
        if (docs.isEmpty) {
          return const Center(child: Text('لا يوجد مستخدمون بعد. أضف إنشاء الملف الشخصي في الخطوة التالية.'));
        }
        return ListView.builder(
          itemCount: docs.length,
          itemBuilder: (context, i) {
            final data = docs[i].data();
            final title = (data['displayName'] as String?) ?? (data['phoneNumber'] as String?) ?? 'مستخدم';
            return ListTile(
              leading: const CircleAvatar(child: Icon(Icons.person)),
              title: Text(title),
              subtitle: const Text('بدء محادثة'),
              onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => ChatPage(otherUid: docs[i].id, otherName: title),
              )),
            );
          },
        );
      },
    );
  }
}

class ChatPage extends StatefulWidget {
  final String otherUid;
  final String otherName;
  const ChatPage({super.key, required this.otherUid, required this.otherName});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final input = TextEditingController();
  String get myUid => FirebaseAuth.instance.currentUser!.uid;
  String get chatId => ([myUid, widget.otherUid]..sort()).join('_');
  CollectionReference<Map<String, dynamic>> get messages =>
      FirebaseFirestore.instance.collection('chats').doc(chatId).collection('messages');

  Future<void> send() async {
    final body = input.text.trim();
    if (body.isEmpty) return;
    input.clear();
    await messages.add({
      'senderId': myUid,
      'text': body,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await FirebaseFirestore.instance.collection('chats').doc(chatId).set({
      'members': [myUid, widget.otherUid],
      'lastMessage': body,
      'updatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  @override
  void dispose() { input.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.otherName),
        actions: [
          IconButton(tooltip: 'مكالمة صوتية (تحتاج ربط مزود مكالمات)', onPressed: () => _callNotice(context), icon: const Icon(Icons.call)),
          IconButton(tooltip: 'مكالمة فيديو (تحتاج ربط مزود مكالمات)', onPressed: () => _callNotice(context), icon: const Icon(Icons.videocam)),
        ],
      ),
      body: Column(children: [
        Expanded(child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: messages.orderBy('createdAt').snapshots(),
          builder: (context, snapshot) {
            if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
            final docs = snapshot.data!.docs;
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: docs.length,
              itemBuilder: (context, i) {
                final m = docs[i].data();
                final mine = m['senderId'] == myUid;
                return Align(
                  alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                    constraints: const BoxConstraints(maxWidth: 300),
                    decoration: BoxDecoration(
                      color: mine ? const Color(0xFF176B43) : const Color(0xFF252D29),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text((m['text'] as String?) ?? ''),
                  ),
                );
              },
            );
          },
        )),
        SafeArea(child: Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(child: TextField(controller: input, textInputAction: TextInputAction.send,
              onSubmitted: (_) => send(), decoration: const InputDecoration(hintText: 'اكتب رسالة...', border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            IconButton.filled(onPressed: send, icon: const Icon(Icons.send)),
          ]),
        )),
      ]),
    );
  }
}

void _callNotice(BuildContext context) {
  ScaffoldMessenger.of(context).showSnackBar(
    const SnackBar(content: Text('المكالمات تحتاج إعداد مزود صوت/فيديو وإضافة مفاتيح المشروع أولاً.')),
  );
}
